def to_l33t(string):
    for word in range(len(string)):
        if string[word] in ['a', 'A']:
            string = string.replace(string[word], "4")
        if string[word] in ['e', 'E']:
            string = string.replace(string[word], "3")
        if string[word] in ['i', 'I']:
            string = string.replace(string[word], "1")
        if string[word] in ['o', 'O']:
            string = string.replace(string[word], "0")
        if string[word] in ['u', 'U']:
            string = string.replace(string[word], "8")
    return string
