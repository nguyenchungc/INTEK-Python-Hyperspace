from statistics import median
print("Give me a series of numbers and I will give you their median.")
array = []
var = 1
while(var == 1):
    b = input("")
    if b == "":
        if len(array) == 0:
            print("Error, empty dataset")
        else:
            i = median(array)
            print('The median is', i)
        var = 0
    else:
        array.append(int(b))
