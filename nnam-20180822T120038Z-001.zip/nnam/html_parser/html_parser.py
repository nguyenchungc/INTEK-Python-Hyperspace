import re


def html_parser(html):
    p = re.compile(r'<.*?>')
    return p.sub('', html)
