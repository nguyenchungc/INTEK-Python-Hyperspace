def order_words(array):
    if array == []:
        array.append([])
        return array
    else:
        d = {}
        for word in array:
            d.setdefault(len(word), []).append(word)
            result = [d[n] for n in sorted(d, reverse=False)]
            for word in result:
                word.sort()
    return result
