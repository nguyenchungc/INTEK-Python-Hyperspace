def print_tab(array):
    maxcase = 0
    maxlenght = 0
    for word in array:
        if len(word) > maxcase:
            maxcase = len(word)
        for letter in word:
            if len(letter) > maxlenght:
                maxlenght = len(letter)
    print('+'*((maxlenght+2)+(maxcase-2)))
    for word in array:
        rs = '+ '
        for letter in word:
            rs += ' '+letter+' '*(maxlenght-len(letter)+1)
            rs += '+'
        for i in range(maxcase - len(word)):
            rs += ' '*(maxlenght+1)+' '+'+'
        print rs
        print('+'*(maxlenght*maxcase+maxcase*2+8))
    if maxcase == 0:
        print "++"
arr = [["this"], ["~~", "is"], [ "ah!", "oh!", "kind", "", "eh !"], ["1", "2", "3", "of"], ["...", "...", "...", "...", "fun !"]]
print_tab(arr)
