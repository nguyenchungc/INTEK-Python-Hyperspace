def rgb(r, g, b):
    if r < 0 or r > 255 or g < 0 or g > 255 or b < 0 or b > 255:
        return "Invalid argument"
    if r >= 0 and r < 16:
        x = "0"+hex(r)[2:4]
    else:
        x = hex(r)[2:4]

    if g >= 0 and g < 16:
        y = "0"+hex(g)[2:4]
    else:
        y = hex(g)[2:4]

    if b >= 0 and b < 16:
        z = "0"+hex(b)[2:4]
    else:
        z = hex(b)[2:4]

    str = "#" + x + y + z
    return str
