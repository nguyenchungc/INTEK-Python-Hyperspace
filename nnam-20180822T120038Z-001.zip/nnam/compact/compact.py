def compact(array):
    array1 = []
    for word in array:
        if word is not None:
            array1.append(word)
    array = array1
    return array
