def are_ships_destroyed(ships_map, hits_map):
    if sum ( ships_map[i] != hits_map[i] for i in range(len(ships_map))):
        return False
    else:
        return True
