import pyglet, random
from pyglet import media
from pyglet.window import key
#import resources

from pyglet.window import key, mouse

window = pyglet.window.Window(width=1000,height=667)
keys = key.KeyStateHandler()
window.push_handlers(keys)



# player.queue(source)
# image = pyglet.image.load_animation('runningman.gif')
image = pyglet.image.load_animation('runningman.gif')
angel = pyglet.image.load_animation('angel1.gif')
zombie2 = pyglet.image.load_animation('zombie2.gif')
plane = pyglet.image.load_animation('plane.gif')
# wolf = pyglet.image.load_animation('cowboy.gif')
#gameover section
game_over_text = pyglet.text.Label("gameover", x=500, y= 600)
game_over_text.anchor_x = "center"
game_over_text.anchor_x = "center"
game_over_text.italic = True
game_over_text.font_size = 60

gameover = False

#game score
game_score = pyglet.text.Label("score", x=10, y= 10)
game_over_text.anchor_x = "center"
game_over_text.anchor_x = "center"
game_over_text.italic = True
game_over_text.font_size = 60

sprite = pyglet.sprite.Sprite(image,x = 100, y=400)
sprite.dx = 100
sprite.scale = 0.1

zombie2 = pyglet.sprite.Sprite(zombie2, x = 1000, y=100)
zombie2.dx = 100
zombie2.scale = 0.1

angel = pyglet.sprite.Sprite(angel, x = 1000, y=300)
angel.dx = 50
angel.scale = 0.2

plane = pyglet.sprite.Sprite(plane, x = 1010, y=550)
plane.dx = 50
plane.scale = 0.5

# wolf = pyglet.sprite.Sprite(wolf, x = 500, y=90)
# wolf.dx = 20
# wolf.scale = 0.5

#background image
background0 = pyglet.image.load('backgound1.jpg')
background1 = pyglet.image.load('backgound1.jpg')
bg = pyglet.image.load('background.jpeg')

bg0 = pyglet.sprite.Sprite(background0)
bg1 = pyglet.sprite.Sprite(background1, x = 1000)
def update_background(_):
    bg0.x -= 5
    bg1.x -= 5
    if(bg1.x == 0):
        bg0.x = 1000
    if(bg0.x == 0):
        bg1.x = 1000



def update(dt):
    on_draw()
    if not gameover:
        sprite.x += sprite.dx * dt
        if sprite.x > window.width:
           sprite.x = 0
        zombie2.x -= zombie2.dx * dt * 3
        if zombie2.x < 0:
            zombie2.x = 990
        angel.x -= angel.dx * dt * 3
        if angel.x < -200:
            angel.x = 990
        plane.x -= plane.dx *dt
        if plane.x < 0:
            plane.x = 1010


def rotxuong(dt):
    if sprite.y > 100:
        sprite.y -= sprite.dx * dt


@window.event
def on_draw():
    if gameover:
        window.clear()
        bg.blit(0,0)
        game_over_text.draw()

    else:
        window.clear()
        bg0.draw()
        bg1.draw()
        sprite.draw()
        plane.draw()
        zombie2.draw()
        angel.draw()
        game_score.draw()



@window.event
def on_text_motion(motion):
    # if(motion == pyglet.window.key.MOTION_DOWN):
    #     sprite.y -=50
    if(motion == pyglet.window.key.MOTION_UP) and sprite.y < 540:
        sprite.y +=50
    if(motion == pyglet.window.key.MOTION_RIGHT):
        sprite.x +=50
    # if(motion == pyglet.window.key.MOTION_LEFT):
    #    sprite.x -=50
    if sprite.x < 0:
        sprite.x = 0
    if sprite.x > 990:
        sprite.x = 990



def loop(_):
    global gameover
    # print( zombie2.x, zombie2.y)
    if zombie2.x <= sprite.x <= zombie2.x+10 and 0 <= sprite.y <= zombie2.y+100:
        gameover = True
        game_over_text.draw()
    if angel.x <= sprite.x <= angel.x+10 and angel.y-100 <= sprite.y <= angel.y+100:
        gameover = True
        game_over_text.draw()
    if   sprite.x >plane.x+75 and plane.y-50 <= sprite.y <= plane.y+50:
        gameover = True
        game_over_text.draw()




pyglet.clock.schedule_interval(update_background, 1/60)
pyglet.clock.schedule_interval(loop, 0.5/60)
pyglet.clock.schedule_interval(update, 0.5/60)
pyglet.clock.schedule_interval(rotxuong, 0.5/60)

pyglet.app.run()
