import pyglet, random
#import resources

from pyglet.window import key, mouse

window = pyglet.window.Window(width=1000,height=667)
# image = pyglet.image.load_animation('runningman.gif')
image = pyglet.image.load_animation('catcute.gif')



# explosion = pyglet.sprite.Sprite(explosion, x=20, y=20)
# explosion.dx = 100
sprite = pyglet.sprite.Sprite(image, x=20, y=40)
sprite.dx = 100
sprite.scale = 0.3

#background image
bg = pyglet.resource.image('backgound1.jpg')

def update(dt):
    on_draw()
    # explosion.x +=explosion.dx * dt
    # if explosion.x > window.width:
    #     explosion.x = 0
    sprite.x += sprite.dx * dt
    if sprite.x > window.width:
       sprite.x = 0

def rotxuong(dt):
    if sprite.y > 40:
        sprite.y -= sprite.dx * dt


@window.event
def on_draw():
   window.clear()

   bg.blit(0,0)
   sprite.draw()
   # explosion.draw()



@window.event
def on_text_motion(motion):
    # if(motion == pyglet.window.key.MOTION_DOWN):
    #     sprite.y -=50
    # if(motion == pyglet.window.key.MOTION_UP):
        # sprite.y +=50
    if(motion == pyglet.window.key.MOTION_RIGHT):
        sprite.x +=50
    if(motion == pyglet.window.key.MOTION_LEFT):
       sprite.x -=50
    if sprite.x < 0:
        sprite.x = 0
    if sprite.x > 990:
        sprite.x = 990



pyglet.clock.schedule_interval(update, 1/60.0) # update at 60Hz
pyglet.clock.schedule_interval(rotxuong, 1/60)
pyglet.app.run()
