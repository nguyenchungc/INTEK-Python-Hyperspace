def rgb(r, g, b):
    if int(r) not in range(256) or \
       int(g) not in range(256) or \
       int(b) not in range(256):
        return "Invalid argument"
    else:
        hex = "#{:02x}{:02x}{:02x}".format(r, g, b)
        return hex
