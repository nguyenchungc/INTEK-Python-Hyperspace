def html_parser(string):
    start_sep='>'
    end_sep='<'
    result=[]
    tmp=string.split(start_sep)
    for par in tmp:
        if end_sep in par:
            result.append(par.split(end_sep)[0])
    return result

print(html_parser("<html><head><title>Page Title</title></head><body><p>My first <i>paragraph</i>.</p></body></html>"))
