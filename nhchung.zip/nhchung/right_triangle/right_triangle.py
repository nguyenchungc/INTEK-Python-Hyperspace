def right_triangle(a, b, c):
    import math
    if math.pow(int(a), 2) == math.pow(int(b), 2) + math.pow(int(c), 2):
        return True
    elif math.pow(int(b), 2) == math.pow(int(c), 2) + math.pow(int(a), 2):
        return True
    elif math.pow(int(c), 2) == math.pow(int(a), 2) + math.pow(int(b), 2):
        return True
    else:
        return False
