def concat(a, b, c):
    return a.capitalize() + " " + b.lower() + " " + c.upper()
