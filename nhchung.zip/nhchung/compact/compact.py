def compact(array):
    return [letter for letter in array if letter is not None]
