print("What pyramid size do you want?")
value = int(input())
if value % 2 == 0:
    for i in range(0, value//2):
        for j in range(1, value//2 - i):
            print(" ", end="")
        for k in range(0, 2 * i + 1):
            print("#", end="")
        print("")
else:
    for i in range(0, value//2 + 1):
        for j in range(0, value//2 - i):
            print(" ", end="")
        for k in range(0, 2 * i + 1):
            print("#", end="")
        print("")
