n = int(input("input the number: "))
var = str(input("input the string"))
for i in range(n):
    for j in range(n):
        print(var(2) if i in [0, n-1] or j in [0, n-1] else ' ', end='')
    print()
