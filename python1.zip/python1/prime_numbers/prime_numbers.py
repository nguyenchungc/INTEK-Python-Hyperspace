n = int(input("Let's print the prime numbers up to? "))
for i in range(2, n+1):
    for j in range(2, i-1):
        if i % j == 0:
            break
    else:
        print(i)
