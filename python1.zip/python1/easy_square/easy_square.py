value = int(input())
string = input()
if value <= 0:
    print("Invalid value")
elif value == 1:
    print(string[0])
else:
    print(string[0], end="")
    for i in range(value-2):
        print(string[1], end="")
    print(string[0])
    for i in range(value-2):
        print(string[3], end="")
        for j in range(value-2):
            print(" ", end="")
        print(string[4])
    print(string[0], end="")
    for i in range(value-2):
        print(string[2], end="")
    print(string[0])
