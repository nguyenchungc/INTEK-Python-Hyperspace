money = int(input("What's the bill ? "))
if money < 0:
    print("Well, it's you who owes me money then.")
if money == 0:
    print("Oh, it was free !")
if money > 0:
    notes = [10000, 5000, 2000, 1000, 500, 100, 50, 10, 5, 1]
    noteCounter = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    for i, j in zip(notes, noteCounter):
        if money >= i:
            j = money // i
            money = money - j * i
            if i in [500, 100, 50, 10, 5, 1]:
                print(j, i, "coin")
            else:
                print(j, i, "banknote")
