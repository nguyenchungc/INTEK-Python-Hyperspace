count = 0
name = ""
while True:
    name = str(input(""))
    if name != "":
        count = count + 1
    else:
        print(count)
        break
