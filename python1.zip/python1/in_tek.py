number = int(input("value? "))
for num in range(number):
    if (num+1)%5 == 0 and (num+1)%9 == 0:
        print('Intek')
    elif (num+1)%9 == 0:
        print('Tek')
    elif (num+1)%5 == 0:
        print('In')
    else:
        print(num+1)
