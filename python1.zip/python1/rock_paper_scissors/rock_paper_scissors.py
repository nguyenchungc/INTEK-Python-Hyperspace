player1 = input("Player 1? ")
player2 = input("Player 2? ")
if player1 == "rock":
    if player2 == "rock":
        print("Draw.")
    elif player2 == "paper":
        print("Player 2 wins.")
    elif player2 == "scissors":
        print("Player 1 wins.")
    else:
        print("Error.")
elif player1 == "paper":
    if player2 == "paper":
        print("Draw.")
    elif player2 == "rock":
        print("Player 1 wins.")
    elif player2 == "scissors":
        print("Player 2 wins.")
    else:
        print("Error.")
elif player1 == "scissors":
    if player2 == "rock":
        print("Player 2 wins.")
    elif player2 == "paper":
        print("Player 1 wins.")
    elif player2 == "scissors":
        print("Draw.")
    else:
        print("Error.")
else:
    print("Error.")
