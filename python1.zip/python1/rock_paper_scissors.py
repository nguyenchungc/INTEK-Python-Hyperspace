player1 = input("Player 1 ")
player2 = input("Player 2 ")
if player1 == "rock":
    if player2 == "rock":
        print("Draw.")
    elif player2 == "paper":
        print("player 2 wins.")
    elif player2 == "scissors":
        print("player 1 wins.")
    else:
        print("error")
elif player1 == "paper":
    if player2 == "paper":
        print("Draw.")
    elif player2 == "rock":
        print("player 1 wins.")
    elif player2 == "scissors":
        print("player 2 wins.")
    else:
        print("error")
elif player1 == "scissors":
    if player2 == "rock":
        print("player 2 wins.")
    elif player2 == "paper":
        print("player 1 wins.")
    elif player2 == "scissors":
        print("Draw")
    else:
        print("error")
else:
    print("error")
