number = int(input("What is the results?"))
print("OK, let's begin")
while True:
    your = input("Yours guess?")
