user = ""
while True:
    user = input('repl> ')
    if user == 'quit':
        break
    if user == "ls" or user == "cat" or user == "rev" or user == "pwd":
        print("I know the command", user, "!!")
    if len(user) == 6:
        print("My length is", len(user))
    L = ['a', 'e', 'o', 'u', 'i']
    if user[0] in L:
        for i in range(4):
            print(user[1:4])
    if user[0] == "0" and user[-1] != "9":
        for i in range(0, len(user), 1):
            if user[i].isdigit() is True:
                print(user[i])
