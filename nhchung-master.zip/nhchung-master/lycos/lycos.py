def generate_autocomplete(words):
    invert = {}
    for letter in words:
        for i in letter:
            if i not in invert:
                invert[i] = [letter[i]]
            else:
                invert[i].append(letter[i])
    return invert



print(generate_autocomplete(['a', 'abc', 'abd', 'abd', 'b']))
