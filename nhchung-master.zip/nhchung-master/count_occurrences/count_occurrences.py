def count_occurrences(string):
    dictionary = {}
    words = string.split()
    unique_list = set()
    for i in words:
        word = i
        if word not in unique_list:
            unique_list.add(word)
            key = words.count(word)
            if key not in dictionary:
                dictionary[key] = []
            dictionary[key].append(word)
            dictionary[key].sort()
    return dictionary
