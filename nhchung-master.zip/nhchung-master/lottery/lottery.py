from random import randint


def lottery():
    return randint(0, 1000)
