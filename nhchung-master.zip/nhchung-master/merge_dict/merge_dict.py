def merge_dict(dictionaries):
    invert = {}
    for key in dictionaries:
        for i in key:
            if i not in invert:
                invert[i] = [key[i]]
            else:
                invert[i].append(key[i])
    return invert
