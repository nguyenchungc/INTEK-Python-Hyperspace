def board(map):
    for i in range(9):
        print(' '.join(map[i]))


def find(map, play, enemy):
    cango = {}
    for i in range(9):
        for j in range(9):
            t = ""
            t += map[0][j] + map[i][0]  # t to save the progrssing position
            if map[i][j] == '.':
                if j < 8:  # 1st way: LEFT TO RIGHT
                    a = j + 1
                    check = False
                    while map[i][a] == enemy and a <= 7:
                        a += 1
                        check = True
                    if map[i][a] == play and check:
                        cango.setdefault(t, []).append("right")

                if j > 1:  # 2nd way: RIGHT TO LEFT
                    a = j - 1
                    check = False
                    while map[i][a] == enemy and a >= 2:
                        a -= 1
                        check = True
                    if map[i][a] == play and check:
                        cango.setdefault(t, []).append("left")

                if i < 8:  # 3rd way: TOP DOWN
                    a = i + 1
                    check = False
                    while map[a][j] == enemy and a <= 7:
                        a += 1
                        check = True
                    if map[a][j] == play and check:
                        cango.setdefault(t, []).append("down")

                if i > 1:  # 4th way: GO UP
                    a = i - 1
                    check = False
                    while map[a][j] == enemy and a >= 2:
                        a -= 1
                        check = True
                    if map[a][j] == play and check:
                        cango.setdefault(t, []).append("up")

                if i < 8 and j < 8:  # 5th way:right way
                    a = i + 1
                    b = j + 1
                    check = False
                    while map[a][b] == enemy and a <= 7 and b <= 7:
                        a += 1
                        b += 1
                        check = True
                    if map[a][b] == play and check:
                        cango.setdefault(t, []).append("right_down")

                if i > 1 and j > 1:  # 6th way:left up
                    a = i - 1
                    b = j - 1
                    check = False
                    while map[a][b] == enemy and a >= 2 and b >= 2:
                        a -= 1
                        b -= 1
                        check = True
                    if map[a][b] == play and check:
                        cango.setdefault(t, []).append("left_up")

                if i > 1 and j < 8:  # 7th way:right up
                    a = i - 1
                    b = j + 1
                    check = False
                    while map[a][b] == enemy and a >= 2 and b <= 7:
                        a -= 1
                        b += 1
                        check = True
                    if map[a][b] == play and check:
                        cango.setdefault(t, []).append("right_up")

                if i < 8 and j > 1:  # 8th way: left down
                    a = i + 1
                    b = j - 1
                    check = False
                    while map[a][b] == enemy and a <= 7 and b >= 2:
                        a += 1
                        b -= 1
                        check = True
                    if map[a][b] == play and check:
                        cango.setdefault(t, []).append("left_down")
    return cango


def chage(map, play, enemy, position, cango):
    char = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8}
    col = char[position[0]]
    row = int(position[1])
    map[row][col] = play
    for x in cango[position]:
        if x == "right":
            a = col
            while map[row][a + 1] == enemy:
                map[row][a + 1] = play
                a += 1
        if x == "left":
            a = col
            while map[row][a - 1] == enemy:
                map[row][a - 1] = play
                a -= 1
        if x == "down":
            a = row
            while map[a + 1][col] == enemy:
                map[a + 1][col] = play
                a += 1
        if x == "up":
            a = row
            while map[a - 1][col] == enemy:
                map[a - 1][col] = play
                a -= 1
        if x == "right_down":
            a = row
            b = col
            while map[a + 1][b + 1] == enemy:
                map[a + 1][b + 1] = play
                a += 1
                b += 1
        if x == "left_up":
            a = row
            b = col
            while map[a - 1][b - 1] == enemy:
                map[a - 1][b - 1] = play
                a -= 1
                b -= 1
        if x == "right_up":
            a = row
            b = col
            while map[a - 1][b + 1] == enemy:
                map[a - 1][b + 1] = play
                a -= 1
                b += 1
        if x == "left_down":
            a = row
            b = col
            while map[a + 1][b - 1] == enemy:
                map[a + 1][b - 1] = play
                a += 1
                b -= 1
    return map


map = []
map.append([' ', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'])
map.append(['1', '.', '.', '.', '.', '.', '.', '.', '.'])
map.append(['2', '.', '.', '.', '.', '.', '.', '.', '.'])
map.append(['3', '.', '.', '.', '.', '.', '.', '.', '.'])
map.append(['4', '.', '.', '.', 'W', 'B', '.', '.', '.'])
map.append(['5', '.', '.', '.', 'B', 'W', '.', '.', '.'])
map.append(['6', '.', '.', '.', '.', '.', '.', '.', '.'])
map.append(['7', '.', '.', '.', '.', '.', '.', '.', '.'])
map.append(['8', '.', '.', '.', '.', '.', '.', '.', '.'])
cont = True  # check if the game is able to continue
play = "B"  # set up players: 1st is B and 2nd is W
enemy = "W"
while cont is True:  # condition to control the game
    board(map)  # 1st step : print the map
    cango = find(map, play, enemy)  # 2nd step: find the way for player
    if len(cango) == 0:
        print("Player " + play + " cannot play.")
    else:
        x = sorted(cango.keys())  # save the sorted key(way) to x
        position = "aa"  # set up the wrong position for the loops to run
        while position not in cango:  # 3rd step: choose the position
            print("Valid choices: ", end='')
            print(' '.join(x))
            position = input("Player " + play + ": ")
            if position not in cango:
                print(position + ": Invalid choice")
        map = chage(map, play, enemy, position, cango)  # 4th step: change map
    for i in map:  # 5th step: check if the map is able to continue
        if i.count('.') == 0:
            cont = False
        else:
            cont = True
            if play == "B":  # change the role
                play = "W"
            else:
                play = "B"
            if enemy == "B":
                enemy = "W"
            else:
                enemy = "B"
            break
board(map)
print("Player " + enemy + " cannot play.")
board(map)
print("Player " + play + " cannot play.")
count_W = 0
count_B = 0
for i in map:
    count_W += i.count("W")
    count_B += i.count("B")
print("End of the game. W: {}, B: {}".format(count_W, count_B))
if count_B > count_W:
    print("B wins.")
elif count_B < count_W:
    print("W wins.")
else:
    print("Draw.")
