REVERSI TEAM AGREEMENT

THE REVERSI PROJECT HAS BEEN ASSIGNED TO LAM DUC LONG AND NGUYEN HOAI CHUNG

ACCORDING TO THE DISCUSSION:

THE TEAM GOES THE AGREEMENTS WHICH WERE DESCRIBED FOLLOWING:

1. NAME OF THE TEAM: THE WOlVES
2. WORKING HOURS PER PERSON: 6 hours
3. THE FREQUENCY OF CHECKING OTHER'S CODE: The code is made together, so don't need to check
4. STRENGTH AND WEAKNESSESS:
	STRENGTH
Long has a solid background in programing. Therefore, He can well organize the data structures and function throughout the project. 
Strong spirit team and hard-working. Members are Willing to share the understading and clarify the issues. 
	WEAKNESSESS
Chung has no background in programing. Therefore, the progress is quite lower than Long. This is due to explain and searching.
Time is also the weakness of the project.
5. ALLOCATION
Each member was assigned in different roles based on the strength and weakness as mentioned above. Long goes throughout project with coding and development. Chung mainly follow his code and was assigned some minor tasks
6. RESULTS AND STUDY LESSON
The final result has been concluded by the hard working. Each members understood the workflow of the project from input to output. 
The lesson given from this project is the team-working skill and sharing idea together.



 

 

