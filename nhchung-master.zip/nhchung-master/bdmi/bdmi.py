def bdmi(dic):
    invert = {}
    for key in dic:
        for i in dic[key]:
            if i not in invert:
                invert[i] = [key]
            else:
                invert[i].append(key)
    return invert
