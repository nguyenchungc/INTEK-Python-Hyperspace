print("Give me a series of numbers and I will give you their median.")
data = []
while True:
    number = input()
    if number == "":
        break
    else:
        data.append(int(number))
if len(data) < 1:
    print("Error, empty dataset")
else:
    data.sort()
    length = len(data)
    if (length % 2 == 0):
        median = (data[(length)//2] + data[(length)//2-1]) / 2
    else:
        median = data[(length-1)//2]
    print("The median is", median)
