def to_l33t(string):
    for letter in string:
        if letter.lower() == "a":
            string = string.replace(letter, "4")
        if letter.lower() == "e":
            string = string.replace(letter, "3")
        if letter.lower() == "i":
            string = string.replace(letter, "1")
        if letter.lower() == "o":
            string = string.replace(letter, "0")
        if letter.lower() == "u":
            string = string.replace(letter, "8")
    return string
